---
name: reasoning-core
description: Universal problem framing, decomposition, relationships, causal chains, hypotheses and interpretation.
---

# reasoning-core

This is a generated Reasoning Workflow Skill Family. Use the family index and progressive router; do not bulk-load references.

[Family index](families/core-reasoning.md)
