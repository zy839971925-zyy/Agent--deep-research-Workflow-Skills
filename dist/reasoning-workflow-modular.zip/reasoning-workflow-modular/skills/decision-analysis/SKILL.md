---
name: decision-analysis
description: Objectives, alternatives, measurements, trade-offs and recommendations.
---

# decision-analysis

This is a generated Reasoning Workflow Skill Family. Use the family index and progressive router; do not bulk-load references.

[Family index](families/decision-analysis.md)
