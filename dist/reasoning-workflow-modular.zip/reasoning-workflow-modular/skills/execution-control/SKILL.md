---
name: execution-control
description: Plans, schedules, capabilities, workers, state, checkpoint, recovery and replay safety.
---

# execution-control

This is a generated Reasoning Workflow Skill Family. Use the family index and progressive router; do not bulk-load references.

[Family index](families/execution-control.md)
