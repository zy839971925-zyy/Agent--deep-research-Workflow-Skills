---
name: deep-research
description: Model-driven orientation, evidence needs, retrieval, provenance, freshness and research synthesis.
---

# deep-research

This is a generated Reasoning Workflow Skill Family. Use the family index and progressive router; do not bulk-load references.

[Family index](families/deep-research.md)
