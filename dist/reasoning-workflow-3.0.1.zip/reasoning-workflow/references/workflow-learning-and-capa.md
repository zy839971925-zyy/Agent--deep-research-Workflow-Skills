> Upgrade 2.1: read the updated [host contracts](host-adapter.md) and [migration rules](../UPGRADE.md) for executable admission, review and storage semantics. The shorter root SKILL is the active entry. Older examples are descriptive and must satisfy the current schemas.

# Workflow Learning and CAPA

[← Back to Workflow Learning family](../families/workflow-learning.md) · [Back to root workflow](../SKILL.md)

Use this module only in the maintenance plane, after a run or evaluation has produced external outcome evidence, deterministic findings, independent review, user correction, benchmark results, or another source of genuinely new information.

## Core boundary

Self-learning is not self-editing. A model criticizing its own answer without new evidence may create a **candidate insight**, but cannot validate or promote a canonical learning.

Treat reusable rules and Skills as **earned, not merely written**: a useful-looking heuristic from one run remains a candidate until outcome evidence, counterexamples, regression comparison, and applicability boundaries justify promotion.

## CAPA failure loop

For material workflow nonconformity use:

`failure → containment → root cause → corrective action → regression → verification → effectiveness check → preventive/generalization → closure`

Classify root cause before changing instructions. Useful classes include problem misframing, wrong depth, wrong routing, context overload, missing context, evidence/provenance failure, instruction conflict, model capability limit, tool/runtime failure, validator gap, execution-plan error, schedule/delegation error, and checkpoint/recovery error.

Do not respond to every failure by adding prompt text. Correct the mechanism that allowed the failure.

## Learning tiers

### Tier 1 — Experience memory

Store only validated, portable strategy/recovery/optimization lessons. Retrieve a small number whose applicability conditions match the active Task Profile and current gap. Track whether use helped or harmed.

### Tier 2 — Routing/reference heuristic

A routing lesson may propose changes to depth or reference selection. Promotion requires held-out evaluation against the current baseline and negative controls.

### Tier 3 — Canonical workflow change

Changes to SKILL.md, schemas, policy, validators, closure, authorization or runtime invariants require:

`candidate → minimal regression fixture → offline/shadow eval → baseline comparison → independent review → promote/reject → rollback available`

Never promote a Tier 3 change from a single trajectory.

## Memory hygiene

Validated memory may be promoted, downgraded, deprecated or marked stale. Deprecated/stale lessons are not runtime-retrievable. Prefer compact transferable heuristics over transcript storage. Preserve provenance and counterexamples.

## Applicability challenge and negative transfer

Retrieval is not permission to apply a lesson. Before using a remembered strategy, compare the lesson's applicability conditions and anti-conditions with the current Task Profile, environment, model/runtime capabilities, objective, and failure mode.

Use the smallest decision:

`use | adapt | ignore`

Prefer ignoring a superficially similar lesson when the differences affect its mechanism. Track harmful reuse as negative-transfer evidence and downgrade or narrow the lesson rather than adding compensating prompt text around it.

## Learn from three outcome shapes

Reusable lessons can come from:

- **clean success:** strategy or routing lesson;
- **failure → recovery → success:** recovery lesson;
- **successful but wasteful trajectory:** optimization lesson.

Do not reward a strategy merely because the final task succeeded if it consumed unnecessary context, calls, retries, or review. Efficiency lessons still require regression/quality gates so optimization cannot silently reduce answer quality.

## Learning and CAPA integration

CAPA creates a learning candidate only after corrective action passes verification and an effectiveness observation supports generalization. A one-off fix is not automatically a reusable lesson.

## Runtime isolation

Learning Plane is not part of normal task context. Ordinary runs may retrieve only a small validated experience-memory subset selected from the active profile and gap. Canonical Skill edits remain maintenance operations.

---

**Routing rule:** Return to the governing router after this module. `Related ≠ automatic load`; do not recursively load references.
