# Core Reasoning

Always available for substantive tasks. Start light; load only the references needed by the current problem-model gap.

> Return to the governing router after the current module. `Related` never means auto-load.

## References
- [writing-for-the-reader](../references/writing-for-the-reader.md) — Draft or edit in the register the reader needs, preserving facts and voice.
- [specialist-resources](../references/specialist-resources.md) — Find an appropriate specialist or maintained reference and verify how it applies to this stack.
- [`clarification-gate`](../references/clarification-gate.md) — Load when a material ambiguity could justify a user question; resolve accessible context, project evidence, external facts, and safe derivations first.
- [`problem-framing-and-effort`](../references/problem-framing-and-effort.md) — Load only when the active gap matches one of: framing, depth, autonomy, clarification, task-profile, representation.
- [`reasoning-structure-and-decomposition`](../references/reasoning-structure-and-decomposition.md) — Load only when the active gap matches one of: decomposition, recomposition, structure, granularity, reasoning-stagnation.
- [`relationships-and-systems`](../references/relationships-and-systems.md) — Load only when the active gap matches one of: causal-chain, systems, relationships, feedback, mechanism.
- [`hypotheses-and-bias-control`](../references/hypotheses-and-bias-control.md) — Load only when the active gap matches one of: hypotheses, competing-explanations, bias, falsification.
- [`human-context-and-interpretation`](../references/human-context-and-interpretation.md) — Load only when the active gap matches one of: human-context, interpretation, statement.
- [`worked-examples`](../references/worked-examples.md) — Load only when the active gap matches one of: examples, workflow-example.

- [`model-adaptation`](../references/model-adaptation.md) — Load when GPT-6+ and current frontier-model/runtime behavior, compute allocation, delegation, or compaction materially affects the route.
